#include <stdio.h>

 		
float convertFahrenheitToCelsius(float f) {
    return (f- 32) / 1.8;
}

int main() {
    float fahrenheit, celsius;

    
    printf("Temperature in Fahrenheit: ");
    scanf("%f", &fahrenheit);

    
    celsius = convertFahrenheitToCelsius(fahrenheit);

    
    printf("Temperature in Celsius is: %f\n", celsius);

}


    


