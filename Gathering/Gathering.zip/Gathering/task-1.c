#include<stdio.h>

greet() {
    printf("Good Morning");
}

main(){
	greet();
}

